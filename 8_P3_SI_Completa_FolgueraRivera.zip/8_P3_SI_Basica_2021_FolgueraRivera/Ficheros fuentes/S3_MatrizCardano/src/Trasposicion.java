import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
/**
 * Clase utilizada para la logica del cifrado y descifrado
 * @author marco
 *
 */
public class Trasposicion {

	
	boolean traza;
	
	TratamientoFicheros t = new TratamientoFicheros();
	
	/**
	 * 
	 * @param traza para indicar si hay que mostrar informacion extra
	 */
	public Trasposicion(boolean traza) {
		this.traza = traza;
	}

	/**
	 * Metodo que se encarga de comprobar que el fichero de entrada exista y tenga los valores optimos 
	 * para la ejecucion del cifrado del programa
	 * @param c objeto con todos los atributos recopilados del fichero config.txt
	 * @throws IOException
	 */
	protected  void cifrarLlamada(Config c) throws IOException {

		String name=c.getFicheroEntrada();
		traza=c.isTraza();
		String linea=t.leerlinea(name);
		
		
		if(t.comprobarFichero(name)) {
			if(linea==null) {
				System.out.println("------------------------Fichero vacio: se rellenara automaticamente---------");
				File archivo = new File (name);
				Writer fr = new FileWriter (archivo);
				BufferedWriter bw = new BufferedWriter(fr);
				linea="LA VUELTA AL MUNDO EN OCHENTA_DIAS 123";
				bw.write(linea);
				bw.close();

			}
			String corregido="";
			if(linea.length()>999) {
				System.out.println("-------El mensaje a cifrar supera las 999 letras ,ek mensaje se acortara a 999 caracteres-----");
				int i=0;
				while(i<999) {
					corregido=corregido+linea.charAt(i);
					i++;
				}
			}else {
				corregido=linea;
			}
			String p=t.formatearTexto(corregido);


			String p2=t.valdidarTexto(p);
			if(!p2.equals("")) {

				if(traza) {
					System.out.println("Clave que viene:"+corregido);
					System.out.println("Clave formateada:"+p2);
				}
				cifrar(c.getClave(), p2 ,c.getFicheroSalida());	



			}else {
				System.out.println("----------------------------------error----------------------------------");
				System.out.println("El mensaje"+linea+" solo contiene simbolos que imposibilitan su comprension");
				System.out.println("-------------------------------------------------------------------------");
			}


		}else {
			System.out.println("----------------------------------error----------------------------------");
			System.out.println("No existe el fichero con el texto en claro para ser cifrado");
			System.out.println("-------------------------------------------------------------------------");
		}

	}
	/**
	 * Metodo que escribe en el fichero de salida la clave obtenida en el metodo generarClave 
	 * @param fsalida fichero de salida
	 * @throws IOException excepcion de texto
	 */
	public void ClaveAutomatica(String fsalida) throws IOException{

		if(!t.comprobarFichero(fsalida)) {
			if(traza) {
				System.out.println("El fichero de salida no existe se se creara");
			}

			try {
				File archivo2 = new File(fsalida);
				BufferedWriter bw;
				bw = new BufferedWriter(new FileWriter(archivo2));	
			}catch(Exception e) {
				System.out.println("Se cambiara el fichero de salida a salida.txt");
				fsalida="salida.txt";
				File archivo2 = new File(fsalida);
				BufferedWriter bw;
				bw = new BufferedWriter(new FileWriter(archivo2));	
			}
		}

		int[] casillas=generarClave();
		File archivo = new File (fsalida);
		Writer fr = new FileWriter (archivo);
		BufferedWriter bw = new BufferedWriter(fr);	


		bw.write(casillas[0]+" "+casillas[1]+" "+casillas[2]+" "+casillas[3]+" "+casillas[4]+" "+casillas[5]+" "+casillas[6]+" "+casillas[7]+" "+casillas[8]);




		bw.close();

		if(traza) { 
			System.out.print("La nueva clave sera :");
			File archivo2 = new File (fsalida);
			FileReader fr2 = new FileReader (archivo2);
			BufferedReader br2 = new BufferedReader(fr2);
			System.out.println(br2.readLine());
			br2.close();
		}

	}

	/**
	 * Metodo que sirve para generar una clave aleatoria que sirva para cifrar el mensaje por el metodo de la matriz de cardano
	 * Devuelve un vector de numeros (la clave)
	 * @return vector de numeros (clave)
	 */
	public int[] generarClave(){
		char matriz[][]=new char[6][6];

		Random random = new Random();

		int[] casillas2 = {-1, -1, -1, -1,-1, -1, -1, -1,-1}; 


		matriz[0][0]='1';
		matriz[0][5]='1';
		matriz[5][5]='1';
		matriz[5][0]='1';

		matriz[0][1]='2';
		matriz[1][5]='2';
		matriz[4][0]='2';
		matriz[5][4]='2';

		matriz[0][2]='3';
		matriz[2][5]='3';
		matriz[3][0]='3';
		matriz[5][3]='3';

		matriz[0][4]='4';
		matriz[1][0]='4';
		matriz[4][5]='4';
		matriz[5][1]='4';


		matriz[1][1]='5';
		matriz[1][4]='5';
		matriz[4][1]='5';
		matriz[4][4]='5';

		matriz[0][3]='7';
		matriz[2][0]='7';
		matriz[3][5]='7';
		matriz[5][2]='7';

		matriz[1][3]='8';
		matriz[2][1]='8';
		matriz[4][2]='8';
		matriz[3][4]='8';

		matriz[2][2]='9';
		matriz[2][3]='9';
		matriz[3][2]='9';
		matriz[3][3]='9';

		matriz[1][2]='6';
		matriz[2][4]='6';
		matriz[3][1]='6';
		matriz[4][3]='6';
		int cont=1;
		for(int i=0;i<casillas2.length ; i++)
		{

			int valorDado = random.nextInt(4);
			switch(valorDado)
			{
			case 0:
				int Acont=1;

				for (int x=0; x <=2; x++) {
					for ( int y=0; y <= 2; y++) {



						if(cont==(matriz[x][y])-'0') {
							casillas2[cont-1]=Acont;

							cont++;

						}
						Acont++;
					}
					Acont=Acont+3;
				}

				break;
			case 1:
				int Bcont=4;


				for (int x=0; x<= 2; x++) {
					for ( int y=3; y <= 5; y++) {


						if(cont==(matriz[x][y])-'0') {
							casillas2[cont-1]=Bcont;

							cont++;

						}
						Bcont++;
					}
					Bcont=Bcont+3;
				}

				break;
			case 2:

				int Ccont=19;



				for (int x=3; x<= 5; x++) {
					for ( int y=0; y <= 2; y++) {



						if(cont==(matriz[x][y])-'0') {
							casillas2[cont-1]=Ccont;

							cont++;

						}
						Ccont++;
					}
					Ccont=Ccont+3;
				}

				break;
			case 3:
				int Dcont=22;


				for (int x=3; x<= 5; x++) {
					for ( int y=3; y <= 5; y++) {

						if(cont==(matriz[x][y])-'0') {
							casillas2[cont-1]=Dcont;

							cont++;

						}
						Dcont++;
					}
					Dcont=Dcont+3;
				}

				break;

			}

		}
		Arrays.sort(casillas2);

		return casillas2;
	}

	/**
	 * Metodo el cual lee el cifrado del fichero se entrada y lo descifra escribiendo el resultado en el fichero de salida
	 * @param c
	 * @throws IOException
	 */
	protected  void Descifrar(Config c) throws IOException {
		String name=c.getFicheroEntrada();
		traza=c.isTraza();
		int []casillas=c.getClave();
		File archivo = new File (name);
		FileReader fr = new FileReader (archivo);
		BufferedReader br = new BufferedReader(fr);

		String palabra;
		palabra=br.readLine();




		if ((palabra.length()%36)==0) {

			int contv=	palabra.length()/36;
			int contmatrices=0;
			String textoClaro="";
			int contm=0;

			try {
				while(contmatrices<contv) {
					if(traza)System.out.println("---------------------------------------------------------------");

					char matriz[][]=new char[6][6];
					char[][] nuevamatriz = new char[6][6];
					char matrizcifrada[][]=new char[6][6];
					int vueltas=0;
					int cont =1;
					int contclave=0;

					for (int x=0; x <6; x++) {
						for ( int y=0; y < 6; y++) {


							if(contclave<9&&cont==casillas[contclave]) {
								matriz[x][y]='-';
								contclave++;
							}
							else {
								matriz[x][y]='+';
							}
							cont ++;
						}
					}
					if(traza) {
						for (int x=0; x < matriz.length; x++) {
							for ( int y=0; y < matriz[x].length; y++) {

								System.out.print (matriz[x][y]+" ");	
							}

							System.out.println("");

						}

						System.out.println("");

					}
					String cifrado="";

					while(vueltas<4) {


						for (int x=0; x <6; x++) {
							for ( int y=0; y < 6; y++) {

								if(matriz[x][y]=='-') {

									matrizcifrada[x][y]=palabra.charAt(contm);
									contm++;


								}else {
									if(vueltas==0) {
										matrizcifrada[x][y]='*';
									}
								}

							}


						}
						if(traza) {
							for (int x=0; x < 6; x++) {
								for ( int y=0; y < 6; y++) {

									System.out.print (matrizcifrada[x][y]+"");	
								}

								System.out.println("");

							}
							System.out.println("");
							System.out.println("");
						}
						for (int x=0;x<6;x++) {
							for (int y=0;y<6;y++) {
								nuevamatriz[y][6-1-x] = matriz[x][y];
							}
						}

						matriz=nuevamatriz;
						nuevamatriz=null;
						nuevamatriz = new char[6][6];

						if(traza) {
							for (int x=0; x < 6; x++) {
								for ( int y=0; y < 6; y++) {

									System.out.print (matriz[x][y]+" ");	
								}

								System.out.println("");

							}


							System.out.println("");
							System.out.println("");
						}
						vueltas++;


					}		
					for (int x=0; x < 6; x++) {
						for ( int y=0; y < 6; y++) {

							textoClaro=textoClaro+matrizcifrada[x][y];
							if(matrizcifrada[x][y]=='*') {
								System.out.println("Error de clave ..La clave proporcionanda no desvela todas las casillas de la matriz");

								throw new Exception();
							}	
						}
					}
					if(traza)System.out.println("El descifrado sera :"+textoClaro);
					contmatrices++;
				}





				

				System.out.println("El texto en claro obtenido del cifrado->["+palabra+"] es ["+textoClaro+"]");
				File archivo2 = new File (c.getFicheroSalida());
				Writer fr2 = new FileWriter (archivo2);
				BufferedWriter bw = new BufferedWriter(fr2);	
				bw.write(textoClaro);
				bw.close();
			}catch(Exception e) {
				System.out.println("--------------------------ERROR AL DESCIFRAR-----------------------------");
				System.out.println("Error al descifrar el mensaje, porque no se sabe la clave");
				System.out.println("-------------------------------------------------------------------------");	
			}
		}else {
			System.out.println("--------------------------ERROR AL DESCIFRAR-----------------------------");
			System.out.println("Error el mensaje cifrado a descifrar no es multiplo exacto de 36");
			System.out.println("-------------------------------------------------------------------------");
		}

	}




/**
 * Metodo que cifra el texto formateado obtenido del metodo CifrarLlamada guardando el criptograma en el fichero de salida
 * @param casillas vector que contiene la clave
 * @param palabra texto en claro a cifrar
 * @param fsalida Nombre del fichero de salida donde se escribe el texto cifrado
 * @throws IOException excepcion de texto
 */
	public  void cifrar(int[] casillas,String palabra,String fsalida) throws IOException {



		String abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		char letter ;
		Random random = new Random();
		int c=0;//numero de matrices


		if(palabra.length()<36) {
			while(palabra.length()<36) {

				letter=abc.charAt(random.nextInt(abc.length()));
				palabra= palabra +(letter);

			}
			c=1;
		}else {

			float tam=palabra.length();
			float r =tam/36;
			c=(int) Math.ceil(r);
		
			if(r<c) {
				while(palabra.length()<c*36) {

					letter=abc.charAt(random.nextInt(abc.length()));
					palabra= palabra +(letter);

				}
			}

		}


		String cifrado="";
		int contmatrices=0;

		//

		while(contmatrices<c) {
			if(traza)System.out.println("---------------------------------------------------------------");

			char matriz[][]=new char[6][6];
			char[][] nuevamatriz = new char[6][6];
			char matrizcifrada[][]=new char[6][6];
			int vueltas=0;
			int cont =1;
			int contclave=0;

			for (int x=0; x <6; x++) {
				for ( int y=0; y < 6; y++) {


					if(contclave<9&&cont==casillas[contclave]) {
						matriz[x][y]='-';
						contclave++;
					}
					else {
						matriz[x][y]='+';
					}
					cont ++;
				}
			}
			if(traza) {
				for (int x=0; x < matriz.length; x++) {
					for ( int y=0; y < matriz[x].length; y++) {

						System.out.print (matriz[x][y]+" ");	
					}

					System.out.println("");

				}
			}

			while(vueltas<4) {

				for (int x=0; x <6; x++) {
					for ( int y=0; y < 6; y++) {

						if(matriz[x][y]=='-') {

							matrizcifrada[x][y]=palabra.charAt(x*6+y+(contmatrices*36));
							cifrado=cifrado+palabra.charAt(x*6+y+(contmatrices*36));


						}else {

							matrizcifrada[x][y]='*';

						}
					}


				}
				if(traza) {
					for (int x=0; x < 6; x++) {
						for ( int y=0; y < 6; y++) {

							System.out.print (matrizcifrada[x][y]+"");	
						}

						System.out.println("");

					}
					System.out.println("");
					System.out.println("");
				}

				for (int x=0;x<6;x++) {
					for (int y=0;y<6;y++) {
						nuevamatriz[y][6-1-x] = matriz[x][y];
					}
				}

				matriz=nuevamatriz;
				nuevamatriz=null;
				nuevamatriz = new char[6][6];

				if(traza) {
					for (int x=0; x < 6; x++) {
						for ( int y=0; y < 6; y++) {

							System.out.print (matriz[x][y]+" ");	
						}

						System.out.println("");

					}
					System.out.println("");
					System.out.println("");
				}
				vueltas++;


			}
			
			if(traza)System.out.println("El cifrado sera :"+cifrado);

			contmatrices++;
		}

		
		if(traza)System.out.println("---------------------------------------------------------------");
		System.out.println("El texto cifrado obtenido a partir del texto en claro es :"+cifrado);
		File archivo = new File (fsalida);
		Writer fr = new FileWriter (archivo);
		BufferedWriter bw = new BufferedWriter(fr);	
		bw.write(cifrado);
		bw.close();




	}

	/**
	 * * Metodo el cual recibe del fichero (entrada.txt) y el texto en claro , lo formatea y escribe en el fichero 
	 * salida.txt sin espacios y comprobando que no aparezcan simbolos extra�os
	 * @param c objeto que contiene la informacion relativa a los ficheros(el nombre)
	 * @throws IOException
	 */
	protected void formateo(Config c) throws IOException {
		TratamientoFicheros t = new TratamientoFicheros();
		String name=c.getFicheroEntrada();

		traza=c.isTraza();



		String linea=t.leerlinea(name);
		if(linea==null) {
			System.out.println("------------------------Fichero vacio: se rellenara automaticamente---------");
			File archivo = new File (name);
			Writer fr = new FileWriter (archivo);
			BufferedWriter bw = new BufferedWriter(fr);

			bw.write("LA VUELTA AL MUNDO EN OCHENTA_DIAS 123");
			bw.close();
			linea="LA VUELTA AL MUNDO EN OCHENTA_DIAS 123";
		}	
		String p=t.formatearTexto(linea);
		String corregido="";
		if(p.length()>999) {
			int i=0;
			while(i<999) {
				corregido=corregido+p.charAt(i);
				i++;
			}
		}else {
			corregido=p;
		}
		String corregido2=t.valdidarTexto(corregido);
		if(traza) {
			System.out.println("-------------------------------------------------------------------------");

			System.out.println("Clave que viene:"+corregido);
			System.out.println("Clave formateada:"+corregido2);
			System.out.println("-------------------------------------------------------------------------");

		}
		if(!corregido2.equals("")) {

		
			File archivo2 = new File (c.getFicheroSalida());
			Writer fr2 = new FileWriter (archivo2);
			BufferedWriter bw2 = new BufferedWriter(fr2);
			bw2.write(corregido2);
			bw2.close();

		}else {

			System.out.println("----------------------------------error----------------------------------");
			System.out.println("El mensaje"+p+" solo contiene simbolos que imposibilitan su comprension");
			System.out.println("-------------------------------------------------------------------------");
		}


	}









}


