import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
/**
 *   Clase encargada de comprobar y formatear el contenido de los ficheros Entrada.txt y Salida.txt
 * @author marco
 *
 */
public class TratamientoFicheros {

	/**
	 *  Metodo que devuelve un boolean=false si se encuentra con un simbolo no perteneciente 
	 * abecedario en mayusculas y minisculas
	 * @param linea texto en claro recopilado del fichero de entrada
	 * @return boolean=false si se encuentra con un simbolo no perteneciente 
	 * abecedario en mayusculas y minisculas
	 * @throws IOException
	 */
	protected String valdidarTexto(String linea) throws IOException {


String linea16="";
boolean facts=false;
		for(int i=0;i<linea.length();i++) {

			if(linea.charAt(i)<65||linea.charAt(i)>122) {
				facts =true;
			}else {
				if(linea.charAt(i)>=91&&linea.charAt(i)<=96) {
					facts =true;

				}

			}
			if(facts) {		
				facts=false;
			}else {
				linea16=linea16+linea.charAt(i);	
			}
			
		}
		return linea16;

	}
	/**
	 * Metodo que elimina los espacion en blanco de la linea pasada por parametros
	 * @param s
	 * @return
	 * @throws IOException
	 */
	protected String formatearTexto(String linea) throws IOException {

		
		String linea16="";
		
			for(int i=0;i<linea.length();i++) {

				if(linea.charAt(i)!=' ') {
					linea16=linea16+linea.charAt(i);
				}
			
		}
		return linea16;

	}
	protected String leerlinea(String s) throws IOException {
		File archivo = new File (s);
		FileReader fr = new FileReader (archivo);
		BufferedReader br = new BufferedReader(fr);
		String lineaaux="";
		String linea;
		while((linea = br.readLine())!=null) { 
			lineaaux=lineaaux+linea;
		} 
	
		return lineaaux;
	}
	
	/**
	 * Comprueba si el fichero( cuyo nombre es pasado por parametros) existe
	 * @param nombre del fichero
	 * @return true=existe  false=noexiste
	 */
	protected boolean comprobarFichero(String n) {
		File file = new File(n);
		if (!file.exists()) {
			return false;
		}
		return true;
	}
	protected boolean ficheroVacio(String name) throws IOException {
		File archivo = new File (name);
		FileReader fr = new FileReader (archivo);
		BufferedReader br = new BufferedReader(fr);
		String linea;
		boolean facts=false;
		while((linea=br.readLine())!=null) {
			facts=true;
		}
		return facts;
	}
}
