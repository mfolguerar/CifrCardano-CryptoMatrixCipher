import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**
 * Clase principal usada para leer el fichero de ejecucion y hacer las llamadas a los metodos necesarios
 * @author marco
 *
 */
public class Main {
	/**
	 * Metodo principal
	 * @param args se le pasan los argumentos desde consola, String el nombre del fichero de configuracion
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException{

		
		
		

		
		
		
		
		if(args.length==0) {
			System.out.println("------------------------------------------error-------------------------------------------");
			System.out.println("--------------No se han introducido parametros de entrada---------------------------------");
			System.out.println("--------------introduce ->-h   para leer elfichero de ayuda-------------------------------");
			System.out.println("--------------introduce ->-f config.txt   para ejecutar el programa-----------------------");
			System.out.println("------------------------------------------------------------------------------------------");

		}else {
			if(args[0].charAt(1)=='f') {
				if(args.length==1) {
					System.out.println("------------------------------------------error-------------------------------------------");
					System.out.println("--------------No se han introducido el archivo de configuracion---------------------------------");
				}else {
					leerConfig(args[1]);
				}
			}else if(args[0].charAt(1)=='h') {
				info();
			}

		}
		
	}

	/**
	 * Metodo principal
	 * Aqui se lee el fichero deconfiguracion y se crea un objeto 
	 * configuracion que va recopilando la informacion proporcionada.
	 * Haciendo las llamadas correspondiente a los metodos de cifrado y descifrado
	 * @param nombre del fichero de configuracion
	 * @throws IOException
	 */
	@SuppressWarnings("resource")
	protected static void leerConfig(String s) throws IOException {

		TratamientoFicheros ta = new TratamientoFicheros();
		if(ta.comprobarFichero(s)) {

			if(ta.comprobarFichero(s)) {
				File archivo = new File (s);
				FileReader fr = new FileReader (archivo);
				BufferedReader br = new BufferedReader(fr);
				String linea;
				boolean traza=true; 
				boolean codificar=true;
				String ficheroEntrada="entrada.txt";
				String ficheroSalida="salida.txt";
				int[] casillas = {3 ,11 ,14 ,16 ,24 ,25 ,28 ,32 ,36}; 
			
				boolean china=true;
				Trasposicion t = new Trasposicion(true);


				while((linea=br.readLine())!=null&&china) {
					
					if(linea.toLowerCase().equals("@ traza off")){
						traza=false;
					}else if(linea.toLowerCase().equals("@ codifica on")) {
						codificar=true;
					}
					else if(linea.toLowerCase().equals("@ codifica off")) {
						codificar=false;
					}else if(linea.equals("")) {

					}
					else if(linea.charAt(0)=='#'&&traza) {
						System.out.println(linea);

					}else if(linea.length()>9&&linea.charAt(0)=='&'&&((linea.charAt(9)=='e')||(linea.charAt(9)=='E'))) {
						int i=17;
						ficheroEntrada="";
						while(i<linea.length()) {
							ficheroEntrada=ficheroEntrada+linea.charAt(i);
							i++;
						}
						if(traza) {
							System.out.println("Fichero de entrada establecido->"+ficheroEntrada);
						}

					}else if(linea.length()>11&&linea.charAt(0)=='&'&&((linea.charAt(11)=='l')||(linea.charAt(11)=='L'))) {
						int i=16;
						ficheroSalida="";
						while(i<linea.length()) {
							ficheroSalida=ficheroSalida+linea.charAt(i);
							i++;
						}
						if(traza) {
							System.out.println("Fichero de salida establecido->"+ficheroSalida);
						}
					}else if(linea.length()>5&&linea.charAt(0)=='&'&&((linea.charAt(3)=='l')||(linea.charAt(3)=='L'))) {
						int i=8;
						int x=0;
						try {
						while(i<linea.length()) {
							if(i==linea.length()-1) {
								casillas[x]=linea.charAt(i)-'0';
								x++;
								i++;
							}else {
								if(linea.charAt(i+1)==' ') {
									casillas[x]=linea.charAt(i)-'0';
									x++;
									i++;
									i++;
								}else {
									String aux=""+linea.charAt(i)+linea.charAt(i+1);
									casillas[x]=Integer.parseInt(aux);
									x++;	
									i++;
									i++;
									i++;
									
								}
							}
						}
						for( i=0;i<casillas.length;i++) {
							
							if(casillas[i]>36||casillas[i]<1) {
								
								casillas[i+10]=3;
								
							}
							
							
							
						}
						 for (i = 0; i < casillas.length - 1; i++) {
					            for (int j = 0; j < casillas.length - i - 1; j++) {
					                if (casillas[j + 1] < casillas[j]) {
					                	casillas[i+10]=3;
					                }
					            }
						 }
						}catch(Exception e) {
							if(traza) {
								System.out.println("!!!!!Error. parametro clave invalido");
								System.out.println("Se establece la clave a : 3 11 14 16 24 25 28 32 36");
								int[] casillas2 = {3 ,11 ,14 ,16 ,24 ,25 ,28 ,32 ,36};
								casillas=casillas2;
							}
						}
						
					}
					
					else if(linea.length()>3&&linea.charAt(0)=='&'&&((linea.charAt(4)=='j')||(linea.charAt(4)=='J'))) {

						if(casillas[0]==-1) {
							if(traza) {
								System.out.println("Vamos a codificar con clave automatica: 3 11 14 16 24 25 28 32 36");
								
							}
							int[] casillas2 = {3 ,11 ,14 ,16 ,24 ,25 ,28 ,32 ,36};
							
							casillas=casillas2;
						}

						if(!ta.comprobarFichero(ficheroEntrada)) {
							if(traza) {
								System.out.println("El fichero de entrada no existe se cambiara a entrada.txt");
							}
							ficheroEntrada="entrada.txt";
							if(!ta.comprobarFichero(ficheroEntrada)) {
								System.out.println("El fichero entrada.txt no existe, se creara uno");
								File archivo2 = new File("entrada.txt");
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));

							}
						}
						if(!ta.comprobarFichero(ficheroSalida)) {
							if(traza) {
								System.out.println("El fichero de salida no existe se crea");
							}

							try {
								File archivo2 = new File(ficheroSalida);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}catch(Exception e) {
								System.out.println("Se cambiara el fichero de salida a salida.txt");
								ficheroSalida="salida.txt";
								File archivo2 = new File(ficheroSalida);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}


						}

						Config config= new Config( traza,  codificar,  ficheroEntrada,  ficheroSalida, casillas);
						
						if(codificar==true) {
							if(traza) {
								System.out.println("Vamos a cifrar el tecto en claro del fichero :"+ficheroEntrada);
							}
							t.cifrarLlamada(config);
						}else {
							if(traza) {
								System.out.println("Vamos a descifrar el mensaje cifrado del fichero :"+ficheroEntrada);
							}
							t.Descifrar(config);
						}

					}else if(linea.length()>4&&linea.charAt(0)=='&'&&linea.charAt(5)=='m') {



						if(traza) {
							System.out.println("Vamos a formatear el contenido del fichero :"+ficheroEntrada);
						}
						if(!ta.comprobarFichero(ficheroEntrada)) {
							if(traza) {
								System.out.println("El fichero de entrada no existe se cambiara a entrada.txt");
							}
							ficheroEntrada="entrada.txt";
							if(!ta.comprobarFichero(ficheroEntrada)) {
								System.out.println("El fichero entrada.txt no existe, se creara uno");
								File archivo2 = new File("entrada.txt");
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));

							}
						}
						if(!ta.comprobarFichero(ficheroSalida)) {
							if(traza) {
								System.out.println("El fichero de salida no existe se se creara");
							}

							try {
								File archivo2 = new File(ficheroSalida);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}catch(Exception e) {
								System.out.println("Se cambiara el fichero de salida a salida.txt");
								ficheroSalida="salida.txt";
								File archivo2 = new File(ficheroSalida);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}
						}
						Config config= new Config( traza,  codificar,  ficheroEntrada,  ficheroSalida,  casillas);
						t.formateo(config);

					}else if(linea.length()>6&&linea.charAt(0)=='&'&&linea.charAt(6)=='r') {


						if(ficheroSalida.equals("")) {
							ficheroSalida="salida.txt";
						}
						if(traza) {
							System.out.println("Vamos a generar una clave aleatoria y guardarla en el fichero de salida establecido: " +ficheroSalida);
						}
						
						t.ClaveAutomatica(ficheroSalida);

					}else if(linea.length()>10&&linea.charAt(0)=='&'&&linea.charAt(10)=='v') {



						if(traza) {
							System.out.println("Vamos a establecer la clave del cifrado usando la que este almacenada en el fichero de entrada : "+ficheroEntrada);
						}
						if(ficheroEntrada.equals("")) {
							ficheroEntrada="entrada.txt";
						}
						if(!ta.comprobarFichero(ficheroEntrada)) {
							if(traza) {
								System.out.println("El fichero de entrada no existe se se creara");
							}

							try {
								File archivo2 = new File(ficheroEntrada);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}catch(Exception e) {
								System.out.println("Se cambiara el fichero de entrada a entrada.txt y se escribira la clave  automatica 3 11 14 16 24 25 28 32 36");
								ficheroEntrada="entrada.txt";
								File archivo2 = new File(ficheroEntrada);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
								
								linea="3 11 14 16 24 25 28 32 36";
								bw.write(linea);
								bw.close();
							}
						}
						
						File archivo1 = new File (ficheroEntrada);
						FileReader fr1 = new FileReader (archivo1);
						BufferedReader br1 = new BufferedReader(fr1);
						String palabra;
						palabra=br1.readLine();
						if (palabra==null||palabra.equals("")) {
							System.out.println("Fichero de entrada vacio se pondra la clave  automatica :3 11 14 16 24 25 28 32 36");
							int[] casillas2 = {3 ,11 ,14 ,16 ,24 ,25 ,28 ,32 ,36};
							casillas=casillas2;
						}else if(Character.isLetter(palabra.charAt(0))) {
							System.out.println("El fichero de entrada contiene texto ");
							System.out.println("Establezca otro fichero de entrada");
						}else {
							int i=0;
							int x=0;
							try {
							while(i<palabra.length()) {
								if(i==palabra.length()-1) {
									casillas[x]=palabra.charAt(i)-'0';
									x++;
									i++;
								}else {
									if(palabra.charAt(i+1)==' ') {
										casillas[x]=palabra.charAt(i)-'0';
										x++;
										i++;
										i++;
									}else {
										String aux=""+palabra.charAt(i)+palabra.charAt(i+1);
										casillas[x]=Integer.parseInt(aux);
										x++;	
										i++;
										i++;
										i++;
										
									}
								}
							}
							for( i=0;i<casillas.length;i++) {
								
								if(casillas[i]>36||casillas[i]<1) {
									
									casillas[i+10]=3;
									
								}
								
								
								
							}
							 for (i = 0; i < casillas.length - 1; i++) {
						            for (int j = 0; j < casillas.length - i - 1; j++) {
						                if (casillas[j + 1] < casillas[j]) {
						                	casillas[i+10]=3;
						                }
						            }
							 }
							}catch(Exception e) {
								if(traza) {
									System.out.println("!!!!!Error. parametro clave invalido");
									System.out.println("Se establece la clave a :3 11 14 16 24 25 28 32 36");
									int[] casillas2 = {3 ,11 ,14 ,16 ,24 ,25 ,28 ,32 ,36};
									casillas=casillas2;
								}
							}
							
						}
							
							
						
						
						
						

					}else {
						if(traza==true&&linea.charAt(0)!='&'&&linea.charAt(0)!='@'&&linea.charAt(0)!='#') {
							System.out.println("Linea ["+linea+"] no prevista");
						}
					}

				}



			}else {
				System.out.println("------------------------Fichero vacio------------------------");
			}
		}else {	
			System.out.println("----------------------------------error----------------------------------");
			System.out.println("No existe el fichero de configuracion con el nombre: "+s);
			System.out.println("-------------------------------------------------------------------------");	
		}


	}
	/**
	 * Metodo el cual lee el fchero leeme.txt el cual contiene la informacion necesaria
	 * para ejecutar las practica correctamente
	 * @throws IOException
	 */
	private static void info() throws IOException {
		File file = new File("leeme.txt");
		if (!file.exists()) {
			System.out.println("El fichero Leeme con informacion de ejecucion no existe");
		}else {
			FileReader fr;
			try {
				fr = new FileReader (file);
				BufferedReader br = new BufferedReader(fr);
				String linea;
				while((linea=br.readLine())!=null) {
					System.out.println(linea);
				}
			} catch (FileNotFoundException e ) {
				e.printStackTrace();
			}			
		}

	}

}
